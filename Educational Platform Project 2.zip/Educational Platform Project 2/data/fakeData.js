/**
 * fakeData.js
 * Contains initial mock data for the application.
 * This data will be loaded into localStorage on first run.
 */

const initialCourses = [
  {
    id: 'course-1',
    title: 'Modern Web Development',
    description: 'Learn how to build responsive, modern websites using HTML5, CSS3, and modern JavaScript features. No frameworks needed!',
    category: 'Programming',
    instructor: 'Alexis McAllister',
    image: 'assets/images/web_dev.png',
    videoUrl: 'assets/intro.mp4',
    materials: [
      { title: 'HTML Reference Sheet', url: 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nDPQM1Qo5ypUMFAwALJMLU31jBQsTAz1LBSK0osSQRLzUouLQQoMzAEZAEeXCQ0KZW5kc3RyZWFtCmVuZG9iagoKMyAwIG9iago0MgplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZTwvTGVuZ3RoMT4+CnN0cmVhbQp4nE2OQQrCMBBF9z3Fl7hJQpqkaVyICL2Ci249gJjShEChpeD1ndS6eP//eT8mAwM9R0rBqR0nEweDjkE2OIZrQcOghRzR0B5Q4Q0N7QUV3tDQ28A8XlHR28AwXjDQ21A0XlDT21A0XkDQ21A0PkDQ80A03lDQ80A03jDQ80A0PrB4XjDQA0A0PrB4PrB4PrB4PgAMu2WbCmVuZHN0cmVhbQplbmRvYmoKCjYgMCBvYmoKMTE5CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMTEgNyAwIFI+Pj4+L0NvbnRlbnRzIDIgMCBSL1BhcmVudCA4IDAgUj4+CmVuZG9iagoKNyAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9IZWx2ZXRpY2EvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCgo4IDAgb2JqCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzQgMCBSXT4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL0NhdGFsb2cvUGFnZXMgOCAwIFI+PgplbmRvYmoKCjkgMCBvYmoKPDwvUHJvZHVjZXIoR2hvc3RzY3JpcHQgOS41MCkvQ3JlYXRpb25EYXRlKEQ6MjAyMTA5MDMwNzI1MjdaMDAnMDAnKT4+CmVuZG9iagoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDQxNiAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAxMjkgMDAwMDAgbiAKMDAwMDAwMDMxNiAwMDAwMCBuIAowMDAwMDAwMTQ5IDAwMDAwIG4gCjAwMDAwMDAyOTUgMDAwMDAgbiAKMDAwMDAwMDQ2NSAwMDAwMCBuIAowMDAwMDAwNTUzIDAwMDAwIG4gCjAwMDAwMDA2MTIgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDEwL1Jvb3QgMSAwIFIvSW5mbyA5IDAgUj4+CnN0YXJ0eHJlZgo3MDgKJSVFT0YK' },
      { title: 'CSS Layout Guide', url: 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nDPQM1Qo5ypUMFAwALJMLU31jBQsTAz1LBSK0osSQRLzUouLQQoMzAEZAEeXCQ0KZW5kc3RyZWFtCmVuZG9iagoKMyAwIG9iago0MgplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZTwvTGVuZ3RoMT4+CnN0cmVhbQp4nE2OQQrCMBBF9z3Fl7hJQpqkaVyICL2Ci249gJjShEChpeD1ndS6eP//eT8mAwM9R0rBqR0nEweDjkE2OIZrQcOghRzR0B5Q4Q0N7QUV3tDQ28A8XlHR28AwXjDQ21A0XlDT21A0XkDQ21A0PkDQ80A03lDQ80A03jDQ80A0PrB4XjDQA0A0PrB4PrB4PrB4PgAMu2WbCmVuZHN0cmVhbQplbmRvYmoKCjYgMCBvYmoKMTE5CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMTEgNyAwIFI+Pj4+L0NvbnRlbnRzIDIgMCBSL1BhcmVudCA4IDAgUj4+CmVuZG9iagoKNyAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9IZWx2ZXRpY2EvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCgo4IDAgb2JqCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzQgMCBSXT4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL0NhdGFsb2cvUGFnZXMgOCAwIFI+PgplbmRvYmoKCjkgMCBvYmoKPDwvUHJvZHVjZXIoR2hvc3RzY3JpcHQgOS41MCkvQ3JlYXRpb25EYXRlKEQ6MjAyMTA5MDMwNzI1MjdaMDAnMDAnKT4+CmVuZG9iagoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDQxNiAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAxMjkgMDAwMDAgbiAKMDAwMDAwMDMxNiAwMDAwMCBuIAowMDAwMDAwMTQ5IDAwMDAwIG4gCjAwMDAwMDAyOTUgMDAwMDAgbiAKMDAwMDAwMDQ2NSAwMDAwMCBuIAowMDAwMDAwNTUzIDAwMDAwIG4gCjAwMDAwMDA2MTIgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDEwL1Jvb3QgMSAwIFIvSW5mbyA5IDAgUj4+CnN0YXJ0eHJlZgo3MDgKJSVFT0YK' }
    ],
    isFeatured: true
  },
  {
    id: 'course-2',
    title: 'UI/UX Design Fundamentals',
    description: 'Master the principles of user interface and user experience design. Learn to create beautiful, usable interfaces from scratch.',
    category: 'Design',
    instructor: 'Sarah Smith',
    image: 'assets/images/ui_ux.png',
    videoUrl: 'assets/intro.mp4',
    materials: [
      { title: 'Design Principles PDF', url: 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nDPQM1Qo5ypUMFAwALJMLU31jBQsTAz1LBSK0osSQRLzUouLQQoMzAEZAEeXCQ0KZW5kc3RyZWFtCmVuZG9iagoKMyAwIG9iago0MgplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZTwvTGVuZ3RoMT4+CnN0cmVhbQp4nE2OQQrCMBBF9z3Fl7hJQpqkaVyICL2Ci249gJjShEChpeD1ndS6eP//eT8mAwM9R0rBqR0nEweDjkE2OIZrQcOghRzR0B5Q4Q0N7QUV3tDQ28A8XlHR28AwXjDQ21A0XlDT21A0XkDQ21A0PkDQ80A03lDQ80A03jDQ80A0PrB4XjDQA0A0PrB4PrB4PrB4PgAMu2WbCmVuZHN0cmVhbQplbmRvYmoKCjYgMCBvYmoKMTE5CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMTEgNyAwIFI+Pj4+L0NvbnRlbnRzIDIgMCBSL1BhcmVudCA4IDAgUj4+CmVuZG9iagoKNyAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9IZWx2ZXRpY2EvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCgo4IDAgb2JqCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzQgMCBSXT4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL0NhdGFsb2cvUGFnZXMgOCAwIFI+PgplbmRvYmoKCjkgMCBvYmoKPDwvUHJvZHVjZXIoR2hvc3RzY3JpcHQgOS41MCkvQ3JlYXRpb25EYXRlKEQ6MjAyMTA5MDMwNzI1MjdaMDAnMDAnKT4+CmVuZG9iagoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDQxNiAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAxMjkgMDAwMDAgbiAKMDAwMDAwMDMxNiAwMDAwMCBuIAowMDAwMDAwMTQ5IDAwMDAwIG4gCjAwMDAwMDAyOTUgMDAwMDAgbiAKMDAwMDAwMDQ2NSAwMDAwMCBuIAowMDAwMDAwNTUzIDAwMDAwIG4gCjAwMDAwMDA2MTIgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDEwL1Jvb3QgMSAwIFIvSW5mbyA5IDAgUj4+CnN0YXJ0eHJlZgo3MDgKJSVFT0YK' }
    ],
    isFeatured: true
  },
  {
    id: 'course-3',
    title: 'Data Science Basics',
    description: 'An introduction to data analysis, visualization, and basic machine learning concepts. Turn raw data into actionable insights.',
    category: 'Data Science',
    instructor: 'Dr. Emily Chen',
    image: 'assets/images/data_science.png',
    videoUrl: 'assets/intro.mp4',
    materials: [
      { title: 'Dataset Examples', url: 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nDPQM1Qo5ypUMFAwALJMLU31jBQsTAz1LBSK0osSQRLzUouLQQoMzAEZAEeXCQ0KZW5kc3RyZWFtCmVuZG9iagoKMyAwIG9iago0MgplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZTwvTGVuZ3RoMT4+CnN0cmVhbQp4nE2OQQrCMBBF9z3Fl7hJQpqkaVyICL2Ci249gJjShEChpeD1ndS6eP//eT8mAwM9R0rBqR0nEweDjkE2OIZrQcOghRzR0B5Q4Q0N7QUV3tDQ28A8XlHR28AwXjDQ21A0XlDT21A0XkDQ21A0PkDQ80A03lDQ80A03jDQ80A0PrB4XjDQA0A0PrB4PrB4PrB4PgAMu2WbCmVuZHN0cmVhbQplbmRvYmoKCjYgMCBvYmoKMTE5CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMTEgNyAwIFI+Pj4+L0NvbnRlbnRzIDIgMCBSL1BhcmVudCA4IDAgUj4+CmVuZG9iagoKNyAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9IZWx2ZXRpY2EvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCgo4IDAgb2JqCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzQgMCBSXT4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL0NhdGFsb2cvUGFnZXMgOCAwIFI+PgplbmRvYmoKCjkgMCBvYmoKPDwvUHJvZHVjZXIoR2hvc3RzY3JpcHQgOS41MCkvQ3JlYXRpb25EYXRlKEQ6MjAyMTA5MDMwNzI1MjdaMDAnMDAnKT4+CmVuZG9iagoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDQxNiAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAxMjkgMDAwMDAgbiAKMDAwMDAwMDMxNiAwMDAwMCBuIAowMDAwMDAwMTQ5IDAwMDAwIG4gCjAwMDAwMDAyOTUgMDAwMDAgbiAKMDAwMDAwMDQ2NSAwMDAwMCBuIAowMDAwMDAwNTUzIDAwMDAwIG4gCjAwMDAwMDA2MTIgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDEwL1Jvb3QgMSAwIFIvSW5mbyA5IDAgUj4+CnN0YXJ0eHJlZgo3MDgKJSVFT0YK' },
      { title: 'Statistics Cheat Sheet', url: 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsOfCjIgMCBvYmoKPDwvTGVuZ3RoIDMgMCBSL0ZpbHRlci9GbGF0ZURlY29kZT4+CnN0cmVhbQp4nDPQM1Qo5ypUMFAwALJMLU31jBQsTAz1LBSK0osSQRLzUouLQQoMzAEZAEeXCQ0KZW5kc3RyZWFtCmVuZG9iagoKMyAwIG9iago0MgplbmRvYmoKCjUgMCBvYmoKPDwvTGVuZ3RoIDYgMCBSL0ZpbHRlci9GbGF0ZURlY29kZTwvTGVuZ3RoMT4+CnN0cmVhbQp4nE2OQQrCMBBF9z3Fl7hJQpqkaVyICL2Ci249gJjShEChpeD1ndS6eP//eT8mAwM9R0rBqR0nEweDjkE2OIZrQcOghRzR0B5Q4Q0N7QUV3tDQ28A8XlHR28AwXjDQ21A0XlDT21A0XkDQ21A0PkDQ80A03lDQ80A03jDQ80A0PrB4XjDQA0A0PrB4PrB4PrB4PgAMu2WbCmVuZHN0cmVhbQplbmRvYmoKCjYgMCBvYmoKMTE5CmVuZG9iagoKNCAwIG9iago8PC9UeXBlL1BhZ2UvTWVkaWFCb3hbMCAwIDU5NSA4NDJdL1Jlc291cmNlczw8L0ZvbnQ8PC9GMTEgNyAwIFI+Pj4+L0NvbnRlbnRzIDIgMCBSL1BhcmVudCA4IDAgUj4+CmVuZG9iagoKNyAwIG9iago8PC9UeXBlL0ZvbnQvU3VidHlwZS9UeXBlMS9CYXNlRm9udC9IZWx2ZXRpY2EvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nPj4KZW5kb2JqCgo4IDAgb2JqCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzQgMCBSXT4+CmVuZG9iagoKMSAwIG9iago8PC9UeXBlL0NhdGFsb2cvUGFnZXMgOCAwIFI+PgplbmRvYmoKCjkgMCBvYmoKPDwvUHJvZHVjZXIoR2hvc3RzY3JpcHQgOS41MCkvQ3JlYXRpb25EYXRlKEQ6MjAyMTA5MDMwNzI1MjdaMDAnMDAnKT4+CmVuZG9iagoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDQxNiAwMDAwMCBuIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAxMjkgMDAwMDAgbiAKMDAwMDAwMDMxNiAwMDAwMCBuIAowMDAwMDAwMTQ5IDAwMDAwIG4gCjAwMDAwMDAyOTUgMDAwMDAgbiAKMDAwMDAwMDQ2NSAwMDAwMCBuIAowMDAwMDAwNTUzIDAwMDAwIG4gCjAwMDAwMDA2MTIgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDEwL1Jvb3QgMSAwIFIvSW5mbyA5IDAgUj4+CnN0YXJ0eHJlZgo3MDgKJSVFT0YK' }
    ],
    isFeatured: false
  }
];

const initialQuizzes = {
  'course-1': [
    {
      question: 'What does HTML stand for?',
      options: ['Hyper Text Markup Language', 'Hyperlinks and Text Markup Language', 'Home Tool Markup Language'],
      correctAnswer: 0
    },
    {
      question: 'Which CSS property controls the text size?',
      options: ['text-style', 'font-size', 'text-size'],
      correctAnswer: 1
    },

    {
      question: 'Which is not a JavaScript data type?',
      options: ['Undefined', 'Number', 'Boolean', 'Float'],
      correctAnswer: 3
    },
    {
      question: 'What does CSS stand for?',
      options: ['Cascading Style Sheets', 'Computer Style Sheets', 'Creative Style Sheets'],
      correctAnswer: 0
    },

    {
      question: 'Which property is used to change the background color?',
      options: ['background-color', 'color', 'bgcolor'],
      correctAnswer: 0
    },
    {
      question: 'How do you write "Hello World" in an alert box?',
      options: ['msg("Hello World");', 'alert("Hello World");', 'msgBox("Hello World");'],
      correctAnswer: 1
    },
    {
      question: 'Which HTML attribute is used to define inline styles?',
      options: ['class', 'style', 'font'],
      correctAnswer: 1
    }
  ],
  'course-2': [
    {
      question: 'What does UX stand for?',
      options: ['User Experience', 'User Exchange', 'Uniform Execution'],
      correctAnswer: 0
    },
    {
      question: 'What is a wireframe in design?',
      options: ['A high-fidelity mockup', 'A blueprint or skeletal framework of a website', 'A colorful prototype'],
      correctAnswer: 1
    },
    {
      question: 'Which color mode is primarily used for digital screens?',
      options: ['CMYK', 'RGB', 'Pantone'],
      correctAnswer: 1
    },
    {
      question: 'What is "Whitespace" in design?',
      options: ['The color white', 'Empty space between and around elements', 'A type of font'],
      correctAnswer: 1
    },
    {
      question: 'What does UI stand for?',
      options: ['User Interface', 'User Integration', 'Uniform Interface'],
      correctAnswer: 0
    },
    {
      question: 'Which principle states that objects near each other tend to be grouped together?',
      options: ['Law of Proximity', 'Law of Similarity', 'Law of Closure'],
      correctAnswer: 0
    },
    {
      question: 'What is a persona in UX?',
      options: ['A fictional character representing a user type', 'A designer\'s portfolio', 'A type of layout'],
      correctAnswer: 0
    },
    {
      question: 'What is Typography?',
      options: ['The art of arranging type', 'The study of maps', 'A photography technique'],
      correctAnswer: 0
    }
  ],
  'course-3': [
    {
      question: 'Which of the following is not a data visualization type?',
      options: ['Bar Chart', 'Scatter Plot', 'If-Else Statement'],
      correctAnswer: 2
    },
    {
      question: 'What does CSV stand for?',
      options: ['Comma Separated Values', 'Computer System Variables', 'Calculated Statistical Vector'],
      correctAnswer: 0
    },
    {
      question: 'Which language is most commonly used for Data Science alongside Python?',
      options: ['HTML', 'R', 'CSS'],
      correctAnswer: 1
    },
    {
      question: 'What is Pandas in the context of Python?',
      options: ['An animal', 'A data manipulation library', 'A web framework'],
      correctAnswer: 1
    },
    {
      question: 'What is the process of cleaning and transforming raw data called?',
      options: ['Data Wrangling', 'Data Hoarding', 'Data Spilling'],
      correctAnswer: 0
    },
    {
      question: 'Which of these is a machine learning algorithm?',
      options: ['Random Forest', 'HTML5', 'CSS Grid'],
      correctAnswer: 0
    },
    {
      question: 'What does "Overfitting" mean?',
      options: ['Model is too simple', 'Model performs well on training data but poorly on new data', 'Model is exactly the right size'],
      correctAnswer: 1
    },
    {
      question: 'Which library is primarily used for numerical operations in Python?',
      options: ['NumPy', 'Django', 'Flask'],
      correctAnswer: 0
    }
  ]
};

// Simple translations dictionary
const translations = {
  en: {
    nav_home: 'Home',
    nav_dashboard: 'Dashboard',
    nav_admin: 'Admin',
    nav_login: 'Login',
    nav_register: 'Register',
    nav_logout: 'Logout',
    hero_title: 'Learn Without Limits',
    hero_subtitle: 'Build skills with courses, certificates, and degrees online from world-class universities and companies.',
    search_placeholder: 'Search for courses...',
    search_button: 'Search',
    featured_courses: 'Featured Courses',
    all_courses: 'All Courses',
    footer_text: '© 2026 Educational Platform. All rights reserved.',
    login_title: 'Welcome Back',
    register_title: 'Create an Account',
    email_label: 'Email Address',
    password_label: 'Password',
    name_label: 'Full Name',
    login_btn: 'Login',
    register_btn: 'Register',
    no_account: 'Don\'t have an account?',
    have_account: 'Already have an account?',
    dashboard_welcome: 'Welcome, ',
    enrolled_courses: 'Enrolled Courses',
    course_progress: 'Your Progress',
    admin_title: 'Course Management',
    add_course_btn: '+ Add New Course'
  },
  es: {
    nav_home: 'Inicio',
    nav_dashboard: 'Panel',
    nav_admin: 'Admin',
    nav_login: 'Iniciar Sesión',
    nav_register: 'Registrarse',
    nav_logout: 'Cerrar Sesión',
    hero_title: 'Aprende Sin Límites',
    hero_subtitle: 'Desarrolla habilidades con cursos en línea de las mejores universidades y empresas.',
    search_placeholder: 'Buscar cursos...',
    search_button: 'Buscar',
    featured_courses: 'Cursos Destacados',
    all_courses: 'Todos los Cursos',
    footer_text: '© 2026 Plataforma Educativa. Todos los derechos reservados.',
    login_title: 'Bienvenido de Nuevo',
    register_title: 'Crear una Cuenta',
    email_label: 'Correo Electrónico',
    password_label: 'Contraseña',
    name_label: 'Nombre Completo',
    login_btn: 'Iniciar Sesión',
    register_btn: 'Registrarse',
    no_account: '¿No tienes una cuenta?',
    have_account: '¿Ya tienes una cuenta?',
    dashboard_welcome: 'Bienvenido, ',
    enrolled_courses: 'Cursos Inscritos',
    course_progress: 'Tu Progreso',
    admin_title: 'Gestión de Cursos',
    add_course_btn: '+ Agregar Nuevo Curso'
  },
  ar: {
    nav_home: 'الرئيسية',
    nav_dashboard: 'لوحة التحكم',
    nav_admin: 'الإدارة',
    nav_login: 'تسجيل الدخول',
    nav_register: 'إنشاء حساب',
    nav_logout: 'تسجيل خروج',
    hero_title: 'تعلم بلا حدود',
    hero_subtitle: 'طور مهاراتك من خلال الدورات والشهادات والدرجات العلمية عبر الإنترنت من جامعات وشركات عالمية.',
    search_placeholder: 'ابحث عن الدورات...',
    search_button: 'بحث',
    featured_courses: 'الدورات المميزة',
    all_courses: 'جميع الدورات',
    footer_text: '© 2026 منصة التعليم. جميع الحقوق محفوظة.',
    login_title: 'مرحباً بعودتك',
    register_title: 'إنشاء حساب جديد',
    email_label: 'البريد الإلكتروني',
    password_label: 'كلمة المرور',
    name_label: 'الاسم الكامل',
    login_btn: 'دخول',
    register_btn: 'تسجيل',
    no_account: 'ليس لديك حساب؟',
    have_account: 'لديك حساب بالفعل؟',
    dashboard_welcome: 'مرحباً، ',
    enrolled_courses: 'الدورات المسجلة',
    course_progress: 'مستوى التقدم',
    admin_title: 'إدارة الدورات',
    add_course_btn: '+ إضافة دورة جديدة'
  }
};
