/**
 * ui.js
 * Handles common UI rendering, navigation updates, and toast notifications.
 */

const UI = {
  // Render navigation based on auth state
  renderNav: function() {
    const user = Auth.getCurrentUser();
    const guestLinks = document.getElementById('guest-links');
    const authLinks = document.getElementById('auth-links');
    const adminLink = document.getElementById('nav-admin');

    if (user) {
      if (guestLinks) guestLinks.classList.add('hidden');
      if (authLinks) authLinks.classList.remove('hidden');
      if (adminLink) {
        if (user.isAdmin) {
          adminLink.classList.remove('hidden');
        } else {
          adminLink.classList.add('hidden');
        }
      }
    } else {
      if (guestLinks) guestLinks.classList.remove('hidden');
      if (authLinks) authLinks.classList.add('hidden');
      if (adminLink) adminLink.classList.add('hidden');
    }
  },

  // Show Toast Notification
  showToast: function(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    toast.innerHTML = `
      <span>${message}</span>
      <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
    `;

    container.appendChild(toast);

    // Auto remove after 3 seconds
    setTimeout(() => {
      if (toast.parentElement) {
        toast.remove();
      }
    }, 3000);
  },

  // Render a list of courses as cards
  renderCourseCards: function(courses, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = ''; // Clear current

    if (courses.length === 0) {
      container.innerHTML = '<p class="text-secondary" style="grid-column: 1/-1; text-align:center;">No courses found.</p>';
      return;
    }

    courses.forEach(course => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <img src="${course.image}" alt="${course.title}" class="card-img" onerror="this.src='https://via.placeholder.com/400x200?text=Course+Image'">
        <div class="card-body">
          <span class="badge">${course.category}</span>
          <h3 class="card-title">${course.title}</h3>
          <p class="card-text">${course.description.substring(0, 100)}...</p>
          <div class="flex justify-between items-center mt-auto" style="margin-top: auto;">
            <a href="course.html?id=${course.id}" class="btn btn-outline btn-sm">View Details</a>
            <span class="text-secondary" style="font-size: 0.875rem;">👨‍🏫 ${course.instructor}</span>
          </div>
        </div>
      `;
      container.appendChild(card);
    });
  },

  // Render Enrolled Courses (with progress)
  renderEnrolledCourses: function(courseIds, containerId, progressObj) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '';

    if (!courseIds || courseIds.length === 0) {
      container.innerHTML = '<p class="text-secondary">You have not enrolled in any courses yet.</p>';
      return;
    }

    courseIds.forEach(id => {
      const course = CourseManager.getCourseById(id);
      if (!course) return;

      const progress = progressObj[id] || 0;

      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <img src="${course.image}" alt="${course.title}" class="card-img" onerror="this.src='https://via.placeholder.com/400x200?text=Course+Image'">
        <div class="card-body">
          <span class="badge">${course.category}</span>
          <h3 class="card-title">${course.title}</h3>
          <div class="progress-container">
            <div class="progress-bar" style="width: ${progress}%"></div>
          </div>
          <p class="text-secondary" style="font-size: 0.875rem; margin-top: 0.5rem; margin-bottom: 1rem;">${progress}% Completed</p>
          <div style="display: flex; gap: 0.5rem;">
            <a href="course.html?id=${course.id}" class="btn btn-primary btn-sm" style="flex: 1;">${progress === 100 ? 'Review' : 'Continue'}</a>
            ${progress === 100 ? `<button class="btn btn-outline btn-sm" style="flex: 1;" onclick="UI.showCertificate('${course.title}', '${Auth.getCurrentUser()?.name}')">Certificate</button>` : ''}
          </div>
        </div>
      `;
      container.appendChild(card);
    });
  },

  // Show Certificate Modal
  showCertificate: function(courseName, userName) {
    let modal = document.getElementById('certificate-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'certificate-modal';
      modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.8); z-index: 1000; display: flex; justify-content: center; align-items: center;';
      modal.innerHTML = `
        <div class="card" style="width: 90%; max-width: 800px; padding: 4rem 2rem; text-align: center; background: white; position: relative; border: 10px solid var(--primary);">
          <button onclick="this.closest('#certificate-modal').style.display='none'" style="position: absolute; top: 1rem; right: 1rem; background: none; border: none; font-size: 1.5rem; cursor: pointer;">&times;</button>
          <h1 style="color: var(--primary); font-size: 3rem; margin-bottom: 1rem;">Certificate of Completion</h1>
          <p style="font-size: 1.25rem; color: var(--secondary);">This is to certify that</p>
          <h2 style="font-size: 2.5rem; margin: 1.5rem 0;" id="cert-user-name"></h2>
          <p style="font-size: 1.25rem; color: var(--secondary);">has successfully completed the course</p>
          <h3 style="font-size: 2rem; margin: 1.5rem 0; color: var(--primary);" id="cert-course-name"></h3>
          <p style="margin-top: 3rem; font-style: italic;">Educational Platform - ${new Date().getFullYear()}</p>
        </div>
      `;
      document.body.appendChild(modal);
    }
    
    document.getElementById('cert-user-name').textContent = userName || 'Student';
    document.getElementById('cert-course-name').textContent = courseName;
    modal.style.display = 'flex';
  }
};

// Initialize UI when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  UI.renderNav();
});
