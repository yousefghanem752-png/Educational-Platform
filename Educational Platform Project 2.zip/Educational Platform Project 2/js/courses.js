/**
 * courses.js
 * Handles course data operations, searching, and interactions like enrolling.
 */

const CourseManager = {
  // Get all courses
  getCourses: function() {
    return JSON.parse(localStorage.getItem('courses')) || [];
  },

  // Get single course
  getCourseById: function(id) {
    const courses = this.getCourses();
    return courses.find(c => c.id === id);
  },

  // Search courses
  searchCourses: function(query) {
    const courses = this.getCourses();
    if (!query.trim()) return courses;
    
    const terms = query.toLowerCase().split(/\s+/).filter(t => t.length > 0);
    
    return courses.filter(c => {
      const searchableText = `${c.title} ${c.description} ${c.category}`.toLowerCase();
      // Ensure ALL terms are found in the searchable text
      return terms.every(term => searchableText.includes(term));
    });
  },

  // Admin: Add course
  addCourse: function(courseData) {
    const courses = this.getCourses();
    const newCourse = {
      id: generateId(),
      ...courseData
    };
    courses.push(newCourse);
    localStorage.setItem('courses', JSON.stringify(courses));
    return newCourse;
  },

  // Admin: Update course
  updateCourse: function(id, courseData) {
    const courses = this.getCourses();
    const index = courses.findIndex(c => c.id === id);
    if (index !== -1) {
      courses[index] = { ...courses[index], ...courseData };
      localStorage.setItem('courses', JSON.stringify(courses));
      return true;
    }
    return false;
  },

  // Admin: Delete course
  deleteCourse: function(id) {
    let courses = this.getCourses();
    courses = courses.filter(c => c.id !== id);
    localStorage.setItem('courses', JSON.stringify(courses));
    return true;
  },

  // Get quizzes for a course
  getQuizzes: function(courseId) {
    const quizzes = JSON.parse(localStorage.getItem('quizzes')) || {};
    return quizzes[courseId] || [];
  },

  // Get forum posts for a course
  getForumPosts: function(courseId) {
    const posts = JSON.parse(localStorage.getItem('forum_posts')) || {};
    return posts[courseId] || [];
  },

  // Add forum post
  addForumPost: function(courseId, content) {
    const user = Auth.getCurrentUser();
    if (!user) return false;

    const posts = JSON.parse(localStorage.getItem('forum_posts')) || {};
    if (!posts[courseId]) {
      posts[courseId] = [];
    }

    const newPost = {
      id: generateId(),
      author: user.name,
      content: content,
      date: new Date().toISOString()
    };

    posts[courseId].push(newPost);
    localStorage.setItem('forum_posts', JSON.stringify(posts));
    return newPost;
  },

  // Enroll in a course
  enrollCourse: function(courseId) {
    const user = Auth.getCurrentUser();
    if (!user) return { success: false, message: 'Must be logged in to enroll' };

    if (user.enrolledCourses.includes(courseId)) {
      return { success: false, message: 'Already enrolled in this course' };
    }

    user.enrolledCourses.push(courseId);
    user.progress[courseId] = 0; // 0% progress
    Auth.updateUser(user);

    return { success: true, message: 'Successfully enrolled!' };
  },

  // Update progress
  updateProgress: function(courseId, percent) {
    const user = Auth.getCurrentUser();
    if (!user) return;

    if (user.enrolledCourses.includes(courseId)) {
      user.progress[courseId] = Math.min(100, Math.max(0, percent));
      Auth.updateUser(user);
    }
  }
};
