/**
 * app.js
 * Core application logic, initialization, and multi-language support.
 */

// Initialize Application Data
function initApp() {
  // Force update courses and quizzes from initial data
  localStorage.setItem('courses', JSON.stringify(initialCourses));
  localStorage.setItem('quizzes', JSON.stringify(initialQuizzes));

  // Initialize Users if not exists
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
  }

  // Initialize Language
  let currentLang = localStorage.getItem('language') || 'en';
  setLanguage(currentLang);

  // Initialize Theme
  let currentTheme = localStorage.getItem('theme') || 'light';
  setTheme(currentTheme);

  // Setup Event Listeners for global elements
  setupGlobalListeners();
}

// Multi-language System
function setLanguage(lang) {
  if (!translations[lang]) return;
  
  localStorage.setItem('language', lang);
  
  // Find all elements with data-i18n attribute and update their text
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang][key]) {
      // Check if it's an input placeholder
      if (el.tagName === 'INPUT' && el.hasAttribute('placeholder')) {
        el.placeholder = translations[lang][key];
      } else {
        el.textContent = translations[lang][key];
      }
    }
  });

  // Handle RTL for Arabic
  if (lang === 'ar') {
    document.documentElement.setAttribute('dir', 'rtl');
    document.body.classList.add('rtl-mode');
  } else {
    document.documentElement.setAttribute('dir', 'ltr');
    document.body.classList.remove('rtl-mode');
  }

  // Update language toggle button text if exists
  const langToggle = document.getElementById('lang-toggle');
  if (langToggle) {
    if (lang === 'en') langToggle.textContent = 'ES';
    else if (lang === 'es') langToggle.textContent = 'AR';
    else langToggle.textContent = 'EN';
  }
}

function toggleLanguage() {
  const currentLang = localStorage.getItem('language') || 'en';
  let nextLang = 'en';
  if (currentLang === 'en') nextLang = 'es';
  else if (currentLang === 'es') nextLang = 'ar';
  setLanguage(nextLang);
}

// Theme System
function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
  
  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.innerHTML = theme === 'light' ? '🌙' : '☀️';
  }
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  setTheme(currentTheme === 'light' ? 'dark' : 'light');
}

// Global Event Listeners
function setupGlobalListeners() {
  const langToggle = document.getElementById('lang-toggle');
  if (langToggle) {
    langToggle.addEventListener('click', toggleLanguage);
  }

  const themeToggle = document.getElementById('theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
  }
}

// Helper to generate unique IDs
function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

// Run init when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);
