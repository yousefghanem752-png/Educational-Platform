/**
 * auth.js
 * Handles user authentication, registration, and session management using localStorage.
 */

const Auth = {
  // Get all users from storage
  getUsers: function() {
    return JSON.parse(localStorage.getItem('users')) || [];
  },

  // Get current logged-in user
  getCurrentUser: function() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
  },

  // Register a new user
  register: function(name, email, password, academicLevel = 'Not Specified') {
    // Validation
    if (!name || !email || !password) {
      return { success: false, message: 'All fields are required' };
    }
    
    if (password.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters' };
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return { success: false, message: 'Invalid email format' };
    }

    const users = this.getUsers();
    
    // Check if email already exists
    if (users.find(u => u.email === email)) {
      return { success: false, message: 'Email already registered' };
    }

    // Create new user object
    const newUser = {
      id: generateId(), // From app.js
      name,
      email,
      password, // In a real app, this would be hashed
      academicLevel,
      enrolledCourses: [],
      progress: {},
      isAdmin: email === 'admin@admin.com' // Simple way to assign admin rights
    };

    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));

    // Auto login after register
    this.setSession(newUser);
    return { success: true, message: 'Registration successful' };
  },

  // Login existing user
  login: function(email, password) {
    if (!email || !password) {
      return { success: false, message: 'Email and password are required' };
    }

    const users = this.getUsers();
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
      this.setSession(user);
      return { success: true, message: 'Login successful' };
    }

    return { success: false, message: 'Invalid email or password' };
  },

  // Set user session
  setSession: function(user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
  },

  // Logout user
  logout: function() {
    localStorage.removeItem('currentUser');
    window.location.href = 'index.html';
  },

  // Middleware to protect routes
  requireAuth: function(redirectUrl = 'login.html') {
    if (!this.getCurrentUser()) {
      window.location.href = redirectUrl;
    }
  },

  // Middleware to protect admin routes
  requireAdmin: function() {
    const user = this.getCurrentUser();
    if (!user || !user.isAdmin) {
      window.location.href = 'index.html';
    }
  },
  
  // Update user data (for enrollment, progress, etc)
  updateUser: function(updatedUser) {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === updatedUser.id);
    if (index !== -1) {
      users[index] = updatedUser;
      localStorage.setItem('users', JSON.stringify(users));
      this.setSession(updatedUser); // Update current session too
    }
  }
};
